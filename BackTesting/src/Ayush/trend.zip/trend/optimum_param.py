
length = 75
mult = 2.6