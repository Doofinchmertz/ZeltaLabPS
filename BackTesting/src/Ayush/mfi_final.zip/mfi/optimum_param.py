
upper_treshold = 77
lower_treshold = 13
period = 10
exit = 13
period_atr = 15
multiplier_atr = 9