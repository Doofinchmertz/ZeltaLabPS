
upper_treshold = 77
lower_treshold = 13
period = 10
exit = 13
period = 15
multiplier = 9